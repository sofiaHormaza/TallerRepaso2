class Rapido extends Enemigo{
    constructor(x,y){
        super(x,y);
    }
    movimiento(){
        this.y+=5;
    }
    pintar(){
        fill(159,213,209);
        rect(this.x,this.y,25,60);
    }
}
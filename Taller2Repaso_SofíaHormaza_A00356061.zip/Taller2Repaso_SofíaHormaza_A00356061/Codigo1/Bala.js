class Bala{
    constructor(x,y){
        this.x=x;
        this.y=y;
    }

    pintar(){
        fill(248,243,43);
        rect(this.x,this.y,10,40);
    }

    disparar(){
        this.y-=10;
    }
}
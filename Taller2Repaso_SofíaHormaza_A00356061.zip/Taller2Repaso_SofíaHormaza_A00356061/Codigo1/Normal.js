class Normal extends Enemigo{
    constructor(x,y){
        super(x,y);
    }
}
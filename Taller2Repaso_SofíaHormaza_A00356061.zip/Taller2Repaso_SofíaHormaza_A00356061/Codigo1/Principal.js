let balas;
let heroe;
let rapidas;
let normales;

balas =[];
normales=[];
rapidas=[];

function setup (){
    createCanvas(600,600);

    heroe= new Heroe (280,530);
}
function draw (){
    background(155);

    fill(255);
    rect(heroe.x,heroe.y,50,50);
    heroe.pintar();

    for(let i=0; i<normales.length; i++){
        let normal = normales[i];
        normal.pintar(normal);
        normal.movimiento(normal);
    }
    if(frameCount %70 ===0){
        normal= new Normal (random(40,560),2);
        normales.push(normal);
    }

    for(let k=0; k<balas.length; k++){
        let bala= balas[k];
        bala.pintar(bala);
        bala.disparar(bala);
    }
    
    for(let k=0; k<balas.length; k++){
        for(let i=0; i<normales.length; i++){
            if(dist(normales[i].x,normales[i].y,balas[k].x,balas[k].y)<=50){
                normales.splice(i,1);
            }
        }
    }
    for(let j=0; j<rapidas.length; j++){
        let rapida = rapidas[j];
        rapida.pintar(rapida);
        rapida.movimiento(rapida);
    }
    if(frameCount %70===0){
        rapida= new Rapido (random(40,560),2);
        rapidas.push(rapida);
    }

    for(let k=0;k<balas.length;k++){
        for(let j=0;j<rapidas.length;j++){
            if(dist(rapidas[j].x,rapidas[j].y,balas[k].x,balas[k].y)<=50){
                rapidas.splice(j,1);
            }
        }
    }

}
function keyPressed(){
    if(keyIsDown(32)){
        bala= new Bala (heroe.x,heroe.y);
        balas.push(bala);
    }
}
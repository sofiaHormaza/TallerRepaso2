class Heroe{
    constructor(x,y,tam){
        this.x=x;
        this.tam=tam;
        this.y=y;
    }
    pintar(){
        if(keyIsDown (LEFT_ARROW)){
            this.x-=3;
        }else if(keyIsDown(RIGHT_ARROW)){
            this.x+=3;
        }
    }
}
class Enemigo{
    constructor(x,y){
        this.x=x;
        this.y=y;
    }
    movimiento(){
        this.y+=1;
    }
    pintar(){
        fill(34,113,179);
        ellipse(this.x,this.y,50,50);
    }
}